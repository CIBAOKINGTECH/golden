import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT=path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR=path.resolve(process.env.DATA_DIR||ROOT);
const PRIVATE=path.resolve(process.env.ADMIN_CONFIG_PATH||path.resolve(ROOT,'..','work','golden-rose-admin.json'));
const CATALOG=path.join(DATA_DIR,'catalog.json');
const UPLOADS=path.join(DATA_DIR,'uploads');
const PORT=Number(process.env.PORT||4177);
const HOST=process.env.HOST||(process.env.PORT?'0.0.0.0':'127.0.0.1');
const sessions=new Map(), attempts=new Map();
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml'};
const seed=[
 {id:'alma',name:'Cartera Alma',category:'Carteras',description:'Una cartera versátil en un delicado tono rosa empolvado. Ideal para acompañarte de día o completar un look especial.',price:1850,image:'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=700&q=80',badge:'Favorito'},
 {id:'siena',name:'Cartera Mini Siena',category:'Carteras',description:'Compacta y encantadora, con un diseño fácil de combinar y el tamaño perfecto para llevar tus esenciales.',price:1490,image:'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=700&q=80',badge:'Nuevo'},
 {id:'serena',name:'Lentes Serena',category:'Accesorios',description:'Lentes de sol con detalles dorados y acabado carey para darle un toque sofisticado a cualquier salida.',price:790,image:'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=700&q=80',badge:'Esencial'},
 {id:'fiesta',name:'Bolso Fiesta',category:'Accesorios',description:'Un bolso pequeño en rosa suave para llevar lo esencial con un toque especial en tus celebraciones.',price:1250,image:'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=700&q=80',badge:'Nuevo'}
];
function readJson(file,fallback){try{return JSON.parse(fs.readFileSync(file,'utf8'))}catch{return fallback}}
fs.mkdirSync(DATA_DIR,{recursive:true});
fs.mkdirSync(path.dirname(PRIVATE),{recursive:true});
let admin=readJson(PRIVATE,null);
if(!admin&&process.env.ADMIN_USER&&process.env.ADMIN_PASSWORD){const salt=crypto.randomBytes(16).toString('hex');admin={username:process.env.ADMIN_USER,salt,hash:hash(process.env.ADMIN_PASSWORD,salt)};fs.writeFileSync(PRIVATE,JSON.stringify(admin,null,2));console.log('Se creó el acceso administrativo inicial desde variables privadas del servidor.')}
if(!admin&&PRIVATE===path.resolve(ROOT,'..','work','golden-rose-admin.json')){console.error(`Falta la configuración privada del administrador: ${PRIVATE}`);process.exit(1)}
if(!admin?.username||!admin?.salt||!admin?.hash){console.error('La configuración del administrador no es válida.');process.exit(1)}
if(!fs.existsSync(CATALOG))fs.writeFileSync(CATALOG,JSON.stringify(seed,null,2));
fs.mkdirSync(UPLOADS,{recursive:true});
function products(){return readJson(CATALOG,seed)}
function send(res,status,data,headers={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers});res.end(JSON.stringify(data))}
function body(req,limit=6_000_000){return new Promise((resolve,reject)=>{let raw='';req.on('data',chunk=>{raw+=chunk;if(raw.length>limit){reject(new Error('La imagen es demasiado grande. Usa una imagen menor de 4 MB.'));req.destroy()}});req.on('end',()=>{try{resolve(JSON.parse(raw||'{}'))}catch{reject(new Error('Los datos enviados no son válidos.'))}});req.on('error',reject)})}
function cookie(req){return(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('gr_session='))?.slice(11)}
function authenticated(req){const token=cookie(req),expiry=sessions.get(token);if(!token||!expiry)return false;if(expiry<Date.now()){sessions.delete(token);return false}sessions.set(token,Date.now()+8*60*60*1000);return true}
function unauthorized(res){send(res,401,{error:'Inicia sesión para continuar.'})}
function hash(password,salt){return crypto.scryptSync(password,salt,64).toString('hex')}
function safeEq(a,b){const x=Buffer.from(a||''),y=Buffer.from(b||'');return x.length===y.length&&crypto.timingSafeEqual(x,y)}
function saveCatalog(list){fs.writeFileSync(CATALOG,JSON.stringify(list,null,2))}
function cleanProduct(input,old={}){const name=String(input.name||'').trim(),description=String(input.description||'').trim(),category=String(input.category||'').trim(),price=Number(input.price);if(!name||!description||!category||!Number.isFinite(price)||price<=0)throw new Error('Completa nombre, descripción, categoría y un precio válido.');let image=old.image||'';if(input.imageData){const found=String(input.imageData).match(/^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=]+)$/);if(!found)throw new Error('Usa una imagen JPG, PNG o WEBP.');const ext=found[1]==='jpeg'?'jpg':found[1],bytes=Buffer.from(found[2],'base64');if(bytes.length>4*1024*1024)throw new Error('La imagen debe pesar menos de 4 MB.');const file=`${crypto.randomUUID()}.${ext}`;fs.writeFileSync(path.join(UPLOADS,file),bytes);image=`/uploads/${file}`}else if(input.imageUrl?.trim())image=input.imageUrl.trim();if(!image)throw new Error('Añade una foto o un enlace de imagen.');return{...old,id:old.id||crypto.randomUUID(),name,description,category,price,image,badge:String(input.badge||'').trim()}}
const server=http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost');
 if(req.method==='GET'&&url.pathname==='/api/products')return send(res,200,products());
 if(req.method==='POST'&&url.pathname==='/api/login'){
  const ip=req.socket.remoteAddress||'local',now=Date.now(),bucket=attempts.get(ip)||{count:0,at:now};if(now-bucket.at>15*60_000){bucket.count=0;bucket.at=now}if(bucket.count>=8)return send(res,429,{error:'Demasiados intentos. Espera 15 minutos y vuelve a probar.'});
    try{const input=await body(req,20_000),passHash=hash(String(input.password||''),admin.salt);const ok=String(input.username||'')===admin.username&&safeEq(passHash,admin.hash);if(!ok){bucket.count++;attempts.set(ip,bucket);return send(res,401,{error:'Usuario o contraseña incorrectos.'})}attempts.delete(ip);const token=crypto.randomBytes(32).toString('hex');sessions.set(token,Date.now()+8*60*60*1000);return send(res,200,{ok:true,username:admin.username},{'Set-Cookie':`gr_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${process.env.NODE_ENV==='production'?'; Secure':''}`})}catch(e){return send(res,400,{error:e.message})}
 }
 if(req.method==='POST'&&url.pathname==='/api/logout'){const token=cookie(req);if(token)sessions.delete(token);return send(res,200,{ok:true},{'Set-Cookie':'gr_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})}
 if(url.pathname.startsWith('/api/admin/')&&!authenticated(req))return unauthorized(res);
 if(req.method==='GET'&&url.pathname==='/api/admin/session')return send(res,200,{ok:true,username:admin.username});
 if(req.method==='POST'&&url.pathname==='/api/admin/products'){
  try{const input=await body(req),list=products(),item=cleanProduct(input);list.unshift(item);saveCatalog(list);return send(res,201,item)}catch(e){return send(res,400,{error:e.message})}
 }
 const match=url.pathname.match(/^\/api\/admin\/products\/([\w-]+)$/);
 if(match&&req.method==='PUT'){
  try{const input=await body(req),list=products(),i=list.findIndex(p=>p.id===match[1]);if(i<0)return send(res,404,{error:'No encontramos ese producto.'});list[i]=cleanProduct(input,list[i]);saveCatalog(list);return send(res,200,list[i])}catch(e){return send(res,400,{error:e.message})}
 }
 if(match&&req.method==='DELETE'){const list=products(),next=list.filter(p=>p.id!==match[1]);if(next.length===list.length)return send(res,404,{error:'No encontramos ese producto.'});saveCatalog(next);return send(res,200,{ok:true})}
 if(req.method==='POST'&&url.pathname==='/api/admin/password'){
  try{const input=await body(req,20_000);if(!safeEq(hash(String(input.currentPassword||''),admin.salt),admin.hash))return send(res,401,{error:'La contraseña actual no coincide.'});if(String(input.newPassword||'').length<8)return send(res,400,{error:'La contraseña nueva debe tener al menos 8 caracteres.'});admin.salt=crypto.randomBytes(16).toString('hex');admin.hash=hash(String(input.newPassword),admin.salt);fs.writeFileSync(PRIVATE,JSON.stringify(admin,null,2));sessions.clear();return send(res,200,{ok:true},{'Set-Cookie':'gr_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})}catch(e){return send(res,400,{error:e.message})}
 }
 if(url.pathname.startsWith('/api/'))return send(res,404,{error:'No encontramos esa acción.'});
 if(url.pathname.startsWith('/uploads/')){const file=path.basename(decodeURIComponent(url.pathname.slice('/uploads/'.length)));if(!/^[\w-]+\.(jpg|jpeg|png|webp)$/i.test(file)){res.writeHead(404);return res.end('No se encontró la imagen.')}const imagePath=path.join(UPLOADS,file);return fs.readFile(imagePath,(err,data)=>{if(err){res.writeHead(404);return res.end('No se encontró la imagen.')}res.writeHead(200,{'Content-Type':mime[path.extname(imagePath).toLowerCase()]||'application/octet-stream','Cache-Control':'public, max-age=86400','X-Content-Type-Options':'nosniff'});res.end(data)})}
 const requested=url.pathname==='/'?'/index.html':url.pathname;
 let filename=path.resolve(ROOT,'.'+decodeURIComponent(requested));if(!filename.startsWith(ROOT+path.sep)&&filename!==ROOT)return send(res,403,{error:'Acceso denegado.'});
 fs.readFile(filename,(err,data)=>{if(err){res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});return res.end('No se encontró esta página.')}res.writeHead(200,{'Content-Type':mime[path.extname(filename).toLowerCase()]||'application/octet-stream','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'});res.end(data)})
});
server.listen(PORT,HOST,()=>console.log(`Golden Rose Shop está disponible en http://${HOST}:${PORT}`));
