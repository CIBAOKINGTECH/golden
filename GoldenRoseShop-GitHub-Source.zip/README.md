# Golden Rose Shop

Tienda web para carteras y accesorios, con catálogo, panel privado, carga de fotos y pedidos por WhatsApp.

## Desarrollo local

Requiere Node.js 20 o superior. Configura variables privadas `ADMIN_USER` y `ADMIN_PASSWORD`, luego inicia el servidor con `node server.mjs`. El acceso de administración es `/admin.html`.

## Publicación en Render

Crea un Blueprint desde este repositorio usando `render.yaml`. Render solicitará `ADMIN_PASSWORD`; establece una contraseña fuerte ahí y no la publiques en el repositorio. El Blueprint usa disco persistente para conservar catálogo e imágenes; revisa el precio que Render muestra antes de confirmar.

La carpeta de datos local y las contraseñas no deben subirse a GitHub. `.gitignore` excluye archivos de entorno, credenciales y fotos cargadas localmente.
